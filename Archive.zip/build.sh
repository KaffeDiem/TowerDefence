echo "Building application"
echo "Zipping files"

rm -rf td.love
zip -r td.love fonts images modules entities main.lua conf.lua Map.lua Maphelper.lua lovebird.lua

echo "Temp files td.love added"
